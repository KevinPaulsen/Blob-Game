package jakemcdowell.blobsapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import java.lang.Math;


public class GameActivity extends AppCompatActivity {

    ProgressBar LevelProgress;
    ProgressBar HP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_activity);
        LevelProgress = (ProgressBar)this.findViewById(R.id.progressBar2);
        LevelProgress.setProgress(0);
        HP = (ProgressBar)this.findViewById(R.id.progressBar);
        HP.setProgress(100);
    }
    double totalTaps;
    double LevelM = 0;
    double Difficulty = 1;
    int totallevels = 1;
    public void buttonTestClick(View v){
        v.setX((float) ((Math.random() * 725) + 50));
        v.setY((float) ((Math.random() * 1200) + 220));
        totalTaps = totalTaps+1;
        Button button = (Button)v;
        HP.setProgress((int)((Difficulty-totalTaps)/Difficulty*100));

        if(totalTaps == Difficulty+1){
            LevelM = LevelM+1;
            LevelProgress.setProgress((int)(20*LevelM));
            totalTaps = 0;
            HP.setProgress(100);
        }
        if(LevelM == 5) {
//Activity Change (Backdrop Change,etc)
            LevelM = 0;
            LevelProgress.setProgress(0);
            Difficulty = Difficulty + 2;
            View b = findViewById(R.id.button2);
            b.setVisibility(View.VISIBLE);
            View g = findViewById(R.id.textView2);
            g.setVisibility(View.VISIBLE);
            View c = findViewById(R.id.button);
            c.setVisibility(View.GONE);
            View d = findViewById(R.id.progressBar);
            d.setVisibility(View.GONE);
            View e = findViewById(R.id.progressBar2);
            e.setVisibility(View.GONE);
            TextView f = (TextView) findViewById(R.id.textView1);
            totallevels = totallevels + 1;
        }
    }
    public void nextlevelbuttonclick(View v) {
        TextView f = (TextView) findViewById(R.id.textView1);
        f.setText("Level: "+totallevels);
        View b = findViewById(R.id.button2);
        b.setVisibility(View.GONE);
        View g = findViewById(R.id.textView2);
        g.setVisibility(View.GONE);
        View c = findViewById(R.id.button);
        c.setVisibility(View.VISIBLE);
        View d = findViewById(R.id.progressBar);
        d.setVisibility(View.VISIBLE);
        View e = findViewById(R.id.progressBar2);
        e.setVisibility(View.VISIBLE);
    }
}


